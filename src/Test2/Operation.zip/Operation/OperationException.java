package Test2.Operation;

// Represents an exception thrown by a 'StringOperation' object.
//
public class OperationException extends RuntimeException {

}
