package Test2.Operation;

// Represents an object with a counter.
//
public interface Countable {

    // Returns the value of the counter.
    int count();
}
