package Test2.Car;

import java.util.*;

// Represents a single car of a train.
// 'SingleCar' extends 'Train'.
//
public interface SingleCar extends Train {

    // TODO: default implementation of methods specified in 'Train', if needed.
    //     (may also be implemented in subclasses of 'SingleCar').

}
